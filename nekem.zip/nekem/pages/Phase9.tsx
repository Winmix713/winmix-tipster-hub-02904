// Phase 9 Advanced Features Page

import { Phase9Dashboard } from '@/components/phase9';

const Phase9Page = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <Phase9Dashboard />
    </div>
  );
};

export default Phase9Page;