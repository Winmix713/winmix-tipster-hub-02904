#!/usr/bin/env node

/**
 * Supabase Migrations Runner
 * 
 * Ez a script az összes SQL migrációt futtatja a supabase/migrations/ mappából
 * a Supabase adatbázison.
 * 
 * Használat:
 *   npm run migrate
 *   vagy
 *   node scripts/run-migrations.mjs
 * 
 * Előfeltételek:
 *   - SUPABASE_URL és SUPABASE_SERVICE_KEY környezeti változók beállítva
 *   - supabase/migrations/ mappában az összes SQL fájl
 */

import { createClient } from '@supabase/supabase-js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Supabase kliens inicializálása
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_KEY;

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('❌ Hiba: A SUPABASE_URL és SUPABASE_SERVICE_KEY környezeti változók szükségesek!');
  console.error('Kérjük, állítsd be ezeket a Vercel Dashboard "Vars" szakaszában.');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseServiceKey);

/**
 * Egy SQL fájl betöltése és feldolgozása
 */
async function executeSQLFile(filePath) {
  try {
    const sql = fs.readFileSync(filePath, 'utf-8');
    
    if (!sql.trim()) {
      console.log(`⏭️  Üres fájl: ${path.basename(filePath)}`);
      return { success: true, skipped: true };
    }

    // A SQL több lekérdezést tartalmazhat, ezeket ; alapján választjuk szét
    const queries = sql
      .split(';')
      .map(q => q.trim())
      .filter(q => q.length > 0);

    console.log(`📝 ${path.basename(filePath)} feldolgozása (${queries.length} SQL utasítás)...`);

    // Minden lekérdezés futtatása
    for (const query of queries) {
      const { error } = await supabase.rpc('exec', { sql: query });
      
      if (error) {
        // Bizonyos hibákat figyelmen kívül lehet hagyni (pl. már létező tábla)
        if (error.message.includes('already exists') || error.message.includes('duplicate key')) {
          console.log(`  ⚠️  Figyelmeztetés: ${error.message}`);
        } else {
          throw error;
        }
      }
    }

    console.log(`✅ ${path.basename(filePath)} sikeresen alkalmazva`);
    return { success: true };
  } catch (error) {
    console.error(`❌ Hiba a ${path.basename(filePath)} feldolgozásakor:`, error.message);
    return { success: false, error: error.message };
  }
}

/**
 * Az összes SQL fájl futtatása
 */
async function runAllMigrations() {
  const migrationsDir = path.join(__dirname, '..', 'supabase', 'migrations');

  if (!fs.existsSync(migrationsDir)) {
    console.error(`❌ A migrations mappa nem található: ${migrationsDir}`);
    process.exit(1);
  }

  console.log(`\n🚀 Supabase Migrations Runner elindult`);
  console.log(`📂 Migrációk helye: ${migrationsDir}\n`);

  // SQL fájlok listázása és rendezése (időbeli sorrend szerint)
  const files = fs.readdirSync(migrationsDir)
    .filter(file => file.endsWith('.sql'))
    .sort();

  if (files.length === 0) {
    console.warn('⚠️  Nem találtam SQL fájlokat a migrations mappában');
    process.exit(0);
  }

  console.log(`📊 Talált fájlok: ${files.length}\n`);

  const results = [];
  let successCount = 0;
  let failedCount = 0;

  // Minden fájl feldolgozása szekvenciálisan
  for (const file of files) {
    const filePath = path.join(migrationsDir, file);
    const result = await executeSQLFile(filePath);
    
    results.push({ file, ...result });
    
    if (result.success) {
      successCount++;
    } else {
      failedCount++;
    }

    // Rövid késleltetés a fájlok között
    await new Promise(resolve => setTimeout(resolve, 100));
  }

  // Összefoglaló
  console.log(`\n${'='.repeat(60)}`);
  console.log(`📈 Migrációk befejezve:`);
  console.log(`  ✅ Sikeres: ${successCount}/${files.length}`);
  if (failedCount > 0) {
    console.log(`  ❌ Sikertelen: ${failedCount}/${files.length}`);
  }
  console.log(`${'='.repeat(60)}\n`);

  // Hibás fájlok kilistázása
  const failed = results.filter(r => !r.success);
  if (failed.length > 0) {
    console.log('❌ Sikertelen migrációk:');
    failed.forEach(f => {
      console.log(`  - ${f.file}: ${f.error}`);
    });
    process.exit(1);
  }

  console.log('🎉 Minden migráció sikeresen alkalmazva!');
  process.exit(0);
}

// Migrációk futtatása
runAllMigrations().catch(error => {
  console.error('Nem várt hiba:', error);
  process.exit(1);
});
