// Re-export from the .ts file to maintain compatibility
export { getMatchHistory, matchHistory, generateMatchHistory } from './matchHistory';