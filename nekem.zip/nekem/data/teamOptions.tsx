// Re-export from the .ts file to maintain compatibility
export { LEAGUE_METADATA, LEAGUE_TEAM_OPTIONS, type LeagueKey, type TeamOption } from './teamOptions';