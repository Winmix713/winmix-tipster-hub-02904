// Removed unused import

/**
 * Model Service - Mock implementation until database tables are created
 */

export async function listModels(): Promise<{ id: string; name: string; status: 'production' | 'staging' | 'archived' }[]> {
  // Mock data until database tables are created
  return [
    { id: '1', name: 'Champion Model', status: 'production' as const },
    { id: '2', name: 'Challenger Model A', status: 'staging' as const },
    { id: '3', name: 'Legacy Model', status: 'archived' as const }
  ];
}

export async function registerModel(input: {
  model_name: string;
  model_version: string;
  model_type: string;
  algorithm?: string;
  hyperparameters?: Record<string, unknown>;
  traffic_allocation?: number;
  description?: string;
  is_active?: boolean;
}): Promise<{ id: string }> {
  // Mock implementation
  console.log('Registering model:', input);
  return { id: `model_${Date.now()}` };
}

export async function updateModel(id: string, updates: {
  algorithm?: string;
  hyperparameters?: Record<string, unknown>;
  traffic_allocation?: number;
  description?: string;
  is_active?: boolean;
}): Promise<{ id: string }> {
  // Mock implementation
  console.log('Updating model:', id, updates);
  return { id };
}

export async function deleteModel(id: string): Promise<void> {
  // Mock implementation
  console.log('Deleting model:', id);
}

export function epsilonGreedySelect(models: { id: string; ctr: number }[], epsilon = 0.1): { id: string } {
  if (Math.random() < epsilon && models.length > 0) {
    const randomModel = models[Math.floor(Math.random() * models.length)];
    return { id: randomModel.id };
  } else {
    const bestModel = models.reduce((best, current) => 
      current.ctr > best.ctr ? current : best, models[0] || { id: 'default', ctr: 0 }
    );
    return { id: bestModel.id };
  }
}

export async function promoteChallenger(id: string): Promise<{ ok: true }> {
  // Mock implementation
  console.log('Promoting challenger:', id);
  return { ok: true };
}

export async function createExperiment(input: {
  experiment_name: string;
  champion_model_id: string;
  challenger_model_id: string;
  target_sample_size?: number;
}): Promise<{ id: string }> {
  // Mock implementation
  console.log('Creating experiment:', input);
  return { id: `experiment_${Date.now()}` };
}

export async function evaluateExperiment(id: string): Promise<{ status: 'queued' | 'running' | 'complete' }> {
  // Mock implementation
  console.log('Evaluating experiment:', id);
  return { status: 'complete' };
}
