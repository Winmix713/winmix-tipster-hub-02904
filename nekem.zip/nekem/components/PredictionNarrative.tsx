import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Brain, TrendingUp, AlertTriangle, Lightbulb } from "lucide-react";
import { LoadingSpinner } from "./LoadingSpinner";
import type { TeamStatistics } from "@/types/database";
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";

interface NarrativeFactor {
  factor: string;
  weight: number;
  type: 'supporting' | 'risk';
  description: string;
}

interface NarrativeData {
  narrative: string;
  keyFactors: NarrativeFactor[];
  recommendation: string;
  confidence_level: 'high' | 'medium' | 'low';
}

interface PredictionNarrativeProps {
  teamStats: TeamStatistics;
  teamName: string;
}

const PredictionNarrative = ({ teamStats, teamName }: PredictionNarrativeProps) => {
  const { data: narrative, isLoading } = useQuery({
    queryKey: ['narrative', teamName, teamStats],
    queryFn: async () => {
      const { data, error } = await supabase.functions.invoke('generate-prediction-narrative', {
        body: {
          teamStats,
          teamName
        }
      });

      if (error) throw new Error(error.message);
      return data as NarrativeData;
    },
    staleTime: 10 * 60 * 1000, // 10 minutes
  });

  if (isLoading) {
    return (
      <Card className="p-6">
        <LoadingSpinner size="sm" text="Elemzés generálása..." />
      </Card>
    );
  }

  if (!narrative) {
    return null;
  }

  const supportingFactors = narrative.keyFactors.filter(f => f.type === 'supporting');
  const riskFactors = narrative.keyFactors.filter(f => f.type === 'risk');

  // Prepare data for pie chart (top 5 factors)
  const chartData = narrative.keyFactors.slice(0, 5).map(f => ({
    name: f.factor,
    value: f.weight,
    type: f.type
  }));

  const COLORS = {
    supporting: 'hsl(var(--primary))',
    risk: 'hsl(var(--destructive))',
  };

  const getConfidenceBadgeVariant = (level: string) => {
    switch (level) {
      case 'high': return 'default';
      case 'medium': return 'secondary';
      case 'low': return 'destructive';
      default: return 'outline';
    }
  };

  const getConfidenceLabel = (level: string) => {
    switch (level) {
      case 'high': return '🟢 Magas megbízhatóság';
      case 'medium': return '🟡 Közepes megbízhatóság';
      case 'low': return '🔴 Alacsony megbízhatóság';
      default: return 'Ismeretlen';
    }
  };

  return (
    <div className="space-y-6">
      {/* Narrative Card */}
      <Card className="p-6 bg-gradient-to-br from-primary/5 via-card to-secondary/5 ring-1 ring-border">
        <div className="flex items-start gap-4 mb-4">
          <div className="h-10 w-10 rounded-full bg-primary/10 ring-1 ring-primary/20 grid place-items-center flex-shrink-0">
            <Brain className="w-5 h-5 text-primary" />
          </div>
          <div className="flex-1">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-lg font-semibold text-foreground">Predikciós Elemzés</h3>
              <Badge variant={getConfidenceBadgeVariant(narrative.confidence_level)}>
                {getConfidenceLabel(narrative.confidence_level)}
              </Badge>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              {narrative.narrative}
            </p>
          </div>
        </div>
      </Card>

      {/* Factors Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart */}
        <Card className="p-6">
          <h4 className="text-sm font-semibold text-foreground mb-4 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-primary" />
            Főbb Tényezők Megoszlása
          </h4>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie
                data={chartData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {chartData.map((entry, index) => (
                  <Cell 
                    key={`cell-${index}`} 
                    fill={COLORS[entry.type as keyof typeof COLORS]} 
                  />
                ))}
              </Pie>
              <Tooltip 
                content={({ payload }) => {
                  if (payload && payload.length > 0) {
                    const data = payload[0];
                    return (
                      <div className="bg-card border border-border rounded-lg p-3 shadow-lg">
                        <p className="text-sm font-semibold text-foreground">{data.name}</p>
                        <p className="text-xs text-muted-foreground">Súly: {data.value}%</p>
                      </div>
                    );
                  }
                  return null;
                }}
              />
            </PieChart>
          </ResponsiveContainer>
        </Card>

        {/* Factor Details */}
        <Card className="p-6">
          <h4 className="text-sm font-semibold text-foreground mb-4">Részletes Tényezők</h4>
          <div className="space-y-3 max-h-[250px] overflow-y-auto">
            {narrative.keyFactors.map((factor, index) => (
              <div 
                key={index}
                className="flex items-start gap-3 p-3 rounded-lg bg-muted/30 ring-1 ring-border"
              >
                <div className="flex-shrink-0 mt-0.5">
                  {factor.type === 'supporting' ? (
                    <TrendingUp className="w-4 h-4 text-primary" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 text-destructive" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <span className="text-xs font-semibold text-foreground truncate">
                      {factor.factor}
                    </span>
                    <Badge variant="outline" className="text-xs">
                      {factor.weight}%
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground line-clamp-2">
                    {factor.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Supporting and Risk Factors Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Supporting Factors */}
        {supportingFactors.length > 0 && (
          <Card className="p-5 bg-gradient-to-br from-primary/5 to-card">
            <h4 className="text-sm font-semibold text-primary mb-3 flex items-center gap-2">
              <TrendingUp className="w-4 h-4" />
              Támogató Tényezők ({supportingFactors.length})
            </h4>
            <ul className="space-y-2">
              {supportingFactors.slice(0, 3).map((factor, index) => (
                <li key={index} className="text-xs text-muted-foreground flex items-start gap-2">
                  <span className="text-primary">•</span>
                  <span>{factor.factor} ({factor.weight}%)</span>
                </li>
              ))}
            </ul>
          </Card>
        )}

        {/* Risk Factors */}
        {riskFactors.length > 0 && (
          <Card className="p-5 bg-gradient-to-br from-destructive/5 to-card">
            <h4 className="text-sm font-semibold text-destructive mb-3 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" />
              Kockázati Tényezők ({riskFactors.length})
            </h4>
            <ul className="space-y-2">
              {riskFactors.slice(0, 3).map((factor, index) => (
                <li key={index} className="text-xs text-muted-foreground flex items-start gap-2">
                  <span className="text-destructive">•</span>
                  <span>{factor.factor} ({factor.weight}%)</span>
                </li>
              ))}
            </ul>
          </Card>
        )}
      </div>

      {/* Recommendation */}
      <Card className="p-6 bg-gradient-to-br from-accent/5 via-card to-secondary/5 ring-1 ring-border">
        <div className="flex items-start gap-4">
          <div className="h-10 w-10 rounded-full bg-accent/10 ring-1 ring-accent/20 grid place-items-center flex-shrink-0">
            <Lightbulb className="w-5 h-5 text-accent" />
          </div>
          <div>
            <h4 className="text-sm font-semibold text-foreground mb-2">Ajánlás</h4>
            <p className="text-sm text-muted-foreground leading-relaxed">
              {narrative.recommendation}
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default PredictionNarrative;
