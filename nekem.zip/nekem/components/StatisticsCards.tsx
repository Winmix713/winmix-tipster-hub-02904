// Re-export from dashboard subdirectory to maintain compatibility
export { default } from '@/components/dashboard/StatisticsCards';