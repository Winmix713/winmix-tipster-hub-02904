export interface Phase9DashboardProps {
  // TODO: Add proper props interface
  [key: string]: unknown;
}