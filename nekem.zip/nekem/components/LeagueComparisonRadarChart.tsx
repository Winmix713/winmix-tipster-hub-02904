// Re-export from crossleague subdirectory to maintain compatibility
export { default } from '@/components/crossleague/LeagueComparisonRadarChart';
export type { LeagueRadarMetric } from '@/components/crossleague/LeagueComparisonRadarChart.types';