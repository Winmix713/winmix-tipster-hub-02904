// Re-export from crossleague subdirectory to maintain compatibility
export { default } from '@/components/crossleague/CorrelationHeatmap';