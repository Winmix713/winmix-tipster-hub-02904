/** @deprecated Use @/integrations/supabase/client instead */
export { supabase } from '@/integrations/supabase/client';
export { type Database } from '@/integrations/supabase/types';
export { supabase as default } from '@/integrations/supabase/client';
