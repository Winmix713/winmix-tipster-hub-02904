import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface NarrativeFactor {
  factor: string;
  weight: number;
  type: 'supporting' | 'risk';
  description: string;
}

interface NarrativeResponse {
  narrative: string;
  keyFactors: NarrativeFactor[];
  recommendation: string;
  confidence_level: 'high' | 'medium' | 'low';
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { teamStats, teamName } = await req.json();

    if (!teamStats || !teamName) {
      throw new Error('teamStats and teamName are required');
    }

    console.log(`Generating narrative for team: ${teamName}`);

    const { team_analysis, prediction } = teamStats;

    // Calculate factors and their weights
    const factors: NarrativeFactor[] = [];

    // 1. Home Form (supporting or risk)
    const homeFormWeight = Math.round(team_analysis.home_form_index * 0.35);
    if (team_analysis.home_form_index >= 60) {
      factors.push({
        factor: 'Erős hazai forma',
        weight: homeFormWeight,
        type: 'supporting',
        description: `${team_analysis.home_form_index.toFixed(0)}%-os hazai formindex - a csapat kiválóan teljesít otthon`
      });
    } else if (team_analysis.home_form_index < 40) {
      factors.push({
        factor: 'Gyenge hazai forma',
        weight: homeFormWeight,
        type: 'risk',
        description: `Csak ${team_analysis.home_form_index.toFixed(0)}%-os hazai formindex - gyenge hazai teljesítmény`
      });
    }

    // 2. Away Form
    const awayFormWeight = Math.round(team_analysis.away_form_index * 0.30);
    if (team_analysis.away_form_index >= 60) {
      factors.push({
        factor: 'Jó vendég forma',
        weight: awayFormWeight,
        type: 'supporting',
        description: `${team_analysis.away_form_index.toFixed(0)}%-os vendég formindex - idegenben is megbízható`
      });
    } else if (team_analysis.away_form_index < 40) {
      factors.push({
        factor: 'Gyenge vendég forma',
        weight: awayFormWeight,
        type: 'risk',
        description: `Csak ${team_analysis.away_form_index.toFixed(0)}%-os vendég formindex - idegenben küzd`
      });
    }

    // 3. Goal Scoring Ability
    const goalWeight = Math.round(team_analysis.average_goals.average_total_goals * 10);
    if (team_analysis.average_goals.average_total_goals >= 2.5) {
      factors.push({
        factor: 'Támadó erő',
        weight: goalWeight,
        type: 'supporting',
        description: `Átlagosan ${team_analysis.average_goals.average_total_goals.toFixed(1)} gól/mérkőzés - erős támadójáték`
      });
    } else if (team_analysis.average_goals.average_total_goals < 1.5) {
      factors.push({
        factor: 'Gyenge gólerő',
        weight: goalWeight,
        type: 'risk',
        description: `Csak ${team_analysis.average_goals.average_total_goals.toFixed(1)} gól/mérkőzés átlag - támadásban problémák`
      });
    }

    // 4. Both Teams Score Tendency
    const bttsWeight = Math.round(team_analysis.both_teams_scored_percentage * 0.20);
    if (team_analysis.both_teams_scored_percentage >= 60) {
      factors.push({
        factor: 'Mindkét csapat gólja',
        weight: bttsWeight,
        type: 'risk',
        description: `${team_analysis.both_teams_scored_percentage.toFixed(0)}%-ban mindkét csapat gólt lő - védelem gyengébb`
      });
    }

    // 5. Win Rate
    const winPercentage = team_analysis.head_to_head_stats.home_win_percentage;
    const winWeight = Math.round(winPercentage * 0.30);
    if (winPercentage >= 50) {
      factors.push({
        factor: 'Győzelmi statisztika',
        weight: winWeight,
        type: 'supporting',
        description: `${winPercentage.toFixed(0)}%-os győzelmi arány - következetes teljesítmény`
      });
    } else if (winPercentage < 30) {
      factors.push({
        factor: 'Gyenge eredmények',
        weight: winWeight,
        type: 'risk',
        description: `Csak ${winPercentage.toFixed(0)}% győzelmi arány - nehezen nyer`
      });
    }

    // 6. CSS Score as factor
    const cssWeight = Math.round(prediction.cssScore);
    factors.push({
      factor: 'Predikció megbízhatósága',
      weight: cssWeight,
      type: prediction.cssScore >= 7 ? 'supporting' : 'risk',
      description: `${prediction.cssScore.toFixed(1)}/10 CSS pontszám - ${prediction.cssScore >= 7 ? 'magas megbízhatóság' : 'korlátozott adatok'}`
    });

    // Sort factors by weight
    factors.sort((a, b) => b.weight - a.weight);

    // Generate narrative based on prediction
    let narrative = '';
    const supportingFactors = factors.filter(f => f.type === 'supporting');
    const riskFactors = factors.filter(f => f.type === 'risk');

    // Determine confidence level
    let confidence_level: 'high' | 'medium' | 'low';
    if (prediction.cssScore >= 7.5 && prediction.confidence >= 0.7) {
      confidence_level = 'high';
    } else if (prediction.cssScore >= 6 && prediction.confidence >= 0.5) {
      confidence_level = 'medium';
    } else {
      confidence_level = 'low';
    }

    // Build narrative
    if (prediction.predictedWinner === 'home') {
      narrative = `${teamName} számára kedvező előrejelzés hazai pályán. `;
      if (supportingFactors.length > 0) {
        narrative += `A csapat erősségei közé tartozik a ${supportingFactors[0].factor.toLowerCase()}, `;
        narrative += `amely jelentős előnyt biztosít a mérkőzésen.`;
      }
    } else if (prediction.predictedWinner === 'away') {
      narrative = `${teamName} esetében gyengébb teljesítmény várható vendégként. `;
      if (riskFactors.length > 0) {
        narrative += `Fő kockázati tényező a ${riskFactors[0].factor.toLowerCase()}, `;
        narrative += `amely hátráltathatja a csapat sikerét.`;
      }
    } else {
      narrative = `${teamName} számára kiegyensúlyozott mérkőzés várható. `;
      narrative += `A statisztikák döntetlen vagy szoros eredményt valószínűsítenek.`;
    }

    // Add goal expectation
    const expectedGoals = prediction.homeExpectedGoals || prediction.awayExpectedGoals || team_analysis.expected_goals;
    narrative += ` Várható gólok száma: ${expectedGoals.toFixed(1)}.`;

    // Generate recommendation
    let recommendation = '';
    if (confidence_level === 'high') {
      recommendation = `Magas megbízhatósággal javasolt a ${prediction.predictedWinner === 'home' ? 'hazai győzelem' : prediction.predictedWinner === 'away' ? 'vendég győzelem' : 'döntetlen'} kimenetelére fogadni. `;
      recommendation += `A CSS pontszám (${prediction.cssScore.toFixed(1)}/10) erős adatbázist jelez.`;
    } else if (confidence_level === 'medium') {
      recommendation = `Közepes bizonyossággal érdemes mérlegelni a fogadást. További elemzés ajánlott a végső döntés előtt.`;
    } else {
      recommendation = `Alacsony megbízhatóság miatt óvatosság javasolt. Több mérkőzés adat szükséges pontosabb előrejelzéshez.`;
    }

    // Add risk warning if needed
    if (riskFactors.length > 0) {
      recommendation += ` Figyelembe veendő kockázatok: ${riskFactors.slice(0, 2).map(f => f.factor.toLowerCase()).join(', ')}.`;
    }

    const response: NarrativeResponse = {
      narrative,
      keyFactors: factors.slice(0, 10), // Top 10 factors
      recommendation,
      confidence_level
    };

    console.log('Narrative generation completed successfully');

    return new Response(JSON.stringify(response), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200
    });

  } catch (error: any) {
    console.error('Narrative generation error:', error);
    return new Response(JSON.stringify({
      error: error.message
    }), {
      status: 400,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
